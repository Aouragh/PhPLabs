
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h1>Opdracht 5-2 registreren</h1>
<?php
//gegevens uit het formulier
$nickname = $_POST["naamvak"];
$ww = $_POST["wachtwoord"];
$wwhash = password_hash($ww, PASSWORD_DEFAULT);

//gegevens ophalen uit de database
require_once "opdracht3-1.php";

$sql = $conn->prepare("
			SELECT beznick
			FROM   vorm
		");
$sql ->execute();

//controleren of de nickname al bestaat
$gevonden = false;
foreach ($sql as $rij) {
    if ($nickname == $rij["beznick"])
    {
        $gevonden = true;
    }
}
//melden als de nickname bestaat
//en andere toevoegen aan de tabel
if ($gevonden) {
    echo "The chosen nickname already exists.";
}
else {

    //invoeren gegevens in de tabel
    $wwhash = password_hash($ww, PASSWORD_DEFAULT);

    $sql = $conn->prepare("
							insert into vorm values
							(
								:bez_id, :beznick, :bezww
							)
						");
    $sql->execute([
        "bez_id"   => NULL,
        "beznick" => $nickname,
        "bezww"   => $wwhash

    ]);
    echo "Registration completed";
}
?>
</body>
</html>