<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h1></h1>
<form action="opdracht5-2.php" method="post">
    Nickname:
    <input type="text" 		name="naamvak">  <br>
    Password:
    <input type="password" name="wachtwoord"><br>
    <input type="submit">
</form>
</body>
</html>