<!doctype>
    <html>
<title> Opdracht 3-2read.php </title>


<body>
<h1> Opdracht 3-2 read </h1>
<?php
   require_once "opdracht3-1.php";

    $sql = $conn->prepare("select bez_id, beznick, bezww from vorm");
  $sql->execute();
echo "<table>";

    foreach ($sql as $rij) {
echo "<tr>";
            echo "<td>" . $rij["bez_id"] . "</td>";
            echo "<td>" . $rij["beznick"] . "</td>";
            echo "<td>" . $rij["bezww"] . "</td>";
    }
echo "</tr>";
echo "</table>"
?>
</body>
</html>
