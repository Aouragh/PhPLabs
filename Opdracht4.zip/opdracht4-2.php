<!doctype>
    <html>
<head>
<title> Opdracht 4-2 </title>
</head>
<body>



<?php

    $nickname = $_POST["naamvak"];
    $ww = $_POST["wwvak"];
    $wwhash = password_hash($ww, PASSWORD_DEFAULT);
    $rank = 'user';
    require_once "opdracht3-1.php";

    $sql = $conn->prepare("insert into vorm values (
        :bez_id, :beznick, :bezww)");
$sql->execute([
    "bez_id" => NULL,
    "beznick" => $nickname,
    "bezww" => $wwhash ]);
?>

</body>
