
<html>
<head>
<title> Opdracht 4-1 Create</title>
</head>

<body>
<h1> Opdracht 4-1 Create </h1>
<form action="opdracht4-2.php" method="POST">
    Nickname:
    <input type="text" name="naamvak"> <br />
    Password:
    <input type="password" name="wwvak"> <br />
    <input type="submit">
</form>
</body>
</html>