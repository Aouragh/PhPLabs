<?php
session_start();

session_destroy();

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

<button><a href="Opdracht6.1.php">Inloggen</a></button>
</body>
</html>