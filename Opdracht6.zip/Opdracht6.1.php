
/**
 * Created by PhpStorm.
 * User: moham
 * Date: 28-3-2018
 * Time: 11:10
 */

<?php

session_start();

?>
<html>
    <head lang="en">
        <meta charset="UTF-8">
        <title>Log In</title>
    </head>
<body>
<?php

if(isset($_SESSION['ingelogd'])){
    echo "u bent al ingelogd";
    ?>
    <form action="uitlog.php" method="post">
        <input type="submit" value="Uitloggen"/>
    </form>
<?php
}else{
    ?>


    <form action="Opdracht6.2.php" method="post">
        Email Address: <br>
        <input type="email" name="email">
        <br>
        Password: <br>
        <input type="password" name="password">
        <br>
        Submit: <br>
        <input type="submit" name="submit">
    </form>

<?php
}

?>