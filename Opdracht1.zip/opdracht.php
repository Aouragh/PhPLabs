<?php
/**
 * Created by PhpStorm.
 * User: moham
 * Date: 15-2-2018
 * Time: 13:50
 */


$username = 'root';
$password = '';


$gebruikersnaam = $_POST["bezoekernaam"];
$wachtwoord = $_POST["password"];
$email = $_POST["email"];
$wwhash = password_hash($wachtwoord, PASSWORD_DEFAULT);


try {
    $conn = new PDO("mysql:host=localhost;dbname=bezoekers", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $error) {
    echo $error->getMessage();
}

try {
    $selectUsers = $conn->prepare("INSERT INTO bezoeker (bezoekernaam, password, bezoekeremail) VALUES (:gebruikersnaam, :wachtwoord, :email)");
    $selectUsers->bindParam(":gebruikersnaam", $gebruikersnaam);
    $selectUsers->bindParam(":wachtwoord", $wachtwoord);
    $selectUsers->bindParam(":email", $email);
    $selectUsers->execute();

    echo "Uw bent geregistreerd";


}catch(PDOException $error){
    echo $error->getMessage();
}

?>



