<?php
session_start();
if(isset($_SESSION['admin'])) {
    $user = "root";
    $pass = "";


    try {
        $conn = new PDO("mysql:host=localhost;dbname=social",
            $user, $pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo "Connectie mislukt: " . $e->getMessage();
    }

    $selectUser = $conn->prepare("SELECT * FROM social");
    $selectUser->execute();
    $results = $selectUser->fetchAll(PDO::FETCH_ASSOC);
    foreach ($results as $row) {
        $lastname = htmlentities($row['lastname']);
        $firstname = htmlentities($row['firstname']);
        echo $firstname . '<br>';

    }
}

?>
